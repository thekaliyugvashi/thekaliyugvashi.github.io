
# The Kaliyug Vashi

This is the personal website of **Divyam Bhardwaj**, a passionate BA LLB student, teacher, and creative digital editor.

## 🔹 About the Creator
- 🎓 Law Student at MJPRU, Bareilly
- 🧑‍🏫 Teacher & Mentor
- 🎬 Video Editor and Social Media Influencer
- 🌟 Aspiring Judge

## 🌐 Live Website
👉 [https://thekaliyugvashi.github.io](https://thekaliyugvashi.github.io)

## 📞 Contact
- 📱 Mobile: +91 9528997903
- 📸 Instagram: [@yksharma99](https://www.instagram.com/yksharma99)
